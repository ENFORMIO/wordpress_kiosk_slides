<?php

/**
 * Fired during plugin activation
 *
 * @link       www.enformio.at
 * @since      1.0.0
 *
 * @package    Kiosk_Slides
 * @subpackage Kiosk_Slides/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Kiosk_Slides
 * @subpackage Kiosk_Slides/includes
 * @author     ENFORMIO <office@enformio.at>
 */
class Kiosk_Slides_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
