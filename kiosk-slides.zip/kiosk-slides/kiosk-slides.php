<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              www.enformio.at
 * @since             1.0.0
 * @package           Kiosk_Slides
 *
 * @wordpress-plugin
 * Plugin Name:       WP Kiosk Slides
 * Plugin URI:        https://www.enformio.at/wordpress-kiosk-slides/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            ENFORMIO
 * Author URI:        www.enformio.at
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       kiosk-slides
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'KS_PLUGIN_NAME_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-kiosk-slides-activator.php
 */
function activate_kiosk_slides() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-kiosk-slides-activator.php';
	Kiosk_Slides_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-kiosk-slides-deactivator.php
 */
function deactivate_kiosk_slides() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-kiosk-slides-deactivator.php';
	Kiosk_Slides_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_kiosk_slides' );
register_deactivation_hook( __FILE__, 'deactivate_kiosk_slides' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-kiosk-slides.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_kiosk_slides() {

	$plugin = new Kiosk_Slides();
	$plugin->run();

}
run_kiosk_slides();
